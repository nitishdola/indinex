$('#menu1').hide();
  $('#menu2').hide();
  $('#menu3').hide();
  $("#menu4").hide();
  $("#menu5").hide();
  $("#menu_id").show();
  $("#back_div").show();