<div class="container"> 
<h2>Master Data</h2>            
        <div class="col-sm-12">
          <div class="flex-container">
            <div class="hvr-grow"  id="change" style="cursor: pointer;" >
                <a href="<?php  echo site_url('Masters/company_setup');?>">
                  <div><i class="mdi mdi-view-dashboard text-primary icon-md"></i></div>
                  <div  class="float-center-sub"> Company Setup</div>
                </a>
            </div>
            <div class="hvr-grow"  id="change" style="cursor: pointer;" >
                <a href="<?php  echo site_url('Masters/line_of_business');?>">
                  <div><i class="mdi mdi-view-dashboard text-primary icon-md"></i></div>
                  <div  class="float-center-sub"> Line of Business</div>
                </a>
            </div>
            <div class="hvr-grow" id="display" style="cursor: pointer;" >
                <a href="<?php  echo site_url('Masters/supplier');?>">
                  <div><i class="mdi mdi-view-dashboard text-warning icon-md"></i></div>
                  <div  class="float-center-sub"> Vendor</div>
                </a>
            </div>
            <div class="hvr-grow" id="display" style="cursor: pointer;" >
                <a href="<?php  echo site_url('Masters/customer');?>">
                  <div><i class="mdi mdi-view-dashboard text-warning icon-md"></i></div>
                  <div class="float-center-sub"> Customer</div>
                </a>
            </div> 
            <div class="hvr-grow"  id="create" style="cursor: pointer;" >
                <a href="<?php  echo site_url('Masters/main_storage_location');?>">
                  <div><i class="mdi mdi-home text-success icon-md"></i></div>
                  <div class="float-center-sub"> Plant</div>
                </a>
            </div> 
            <div class="hvr-grow"  id="create" style="cursor: pointer;" >
                <a href="<?php  echo site_url('Masters/storage_location');?>">
                  <div><i class="mdi mdi-home text-success icon-md"></i></div>
                  <div class="float-center-sub"> Storage Location</div>
                </a>
            </div> 
            <div class="hvr-grow" id="display" style="cursor: pointer;" >
                <a href="<?php  echo site_url('Masters/product_master');?>">
                  <div><i class="mdi mdi-view-dashboard text-warning icon-md"></i></div>
                  <div  class="float-center-sub"> Product Master</div>
                </a>
            </div>
            <div class="hvr-grow" id="display" style="cursor: pointer;" >
                <a href="<?php  echo site_url('Masters/product_category');?>">
                  <div><i class="mdi mdi-view-dashboard text-warning icon-md"></i></div>
                  <div  class="float-center-sub"> Product Category</div>
                </a>
                </div>
             <div class="hvr-grow" id="display" style="cursor: pointer;" >
                <a href="<?php  echo site_url('Masters/product_variants');?>">
                  <div><i class="mdi mdi-view-dashboard text-warning icon-md"></i></div>
                  <div  class="float-center-sub"> Product Variants</div>
                </a>
            </div>
           
            <div class="hvr-grow"  id="create" style="cursor: pointer;" >
                <a href="<?php  echo site_url('Masters/holiday_calender');?>">
                  <div><i class="mdi mdi-home text-success icon-md"></i></div>
                  <div  class="float-center-sub"> Holiday List</div>
                </a>
            </div> 
           
            
          </div>
        </div> 
        </div> 
   
        