<!-- Footer -->
    <footer class="site-footer">
      <div class="site-footer-legal">© 2019 <a href="javascript:void(0)">Indigi Consulting And Solutions Pvt. Ltd.</a></div>
      <div class="site-footer-right">
        Crafted with <i class="red-600 icon md-favorite"></i> by <a href="javascript:void(0)">ND.</a>
      </div>
    </footer>
    <!-- Core  -->
    <script src="<?php echo base_url();?>global/vendor/babel-external-helpers/babel-external-helpers.js"></script>
    <script src="<?php echo base_url();?>global/vendor/jquery/jquery.js"></script>
    <script src="<?php echo base_url();?>global/vendor/popper-js/umd/popper.min.js"></script>
    <script src="<?php echo base_url();?>global/vendor/bootstrap/bootstrap.js"></script>
    <script src="<?php echo base_url();?>global/vendor/animsition/animsition.js"></script>
    <script src="<?php echo base_url();?>global/vendor/mousewheel/jquery.mousewheel.js"></script>
    <script src="<?php echo base_url();?>global/vendor/asscrollbar/jquery-asScrollbar.js"></script>
    <script src="<?php echo base_url();?>global/vendor/asscrollable/jquery-asScrollable.js"></script>
    <script src="<?php echo base_url();?>global/vendor/ashoverscroll/jquery-asHoverScroll.js"></script>
    <script src="<?php echo base_url();?>global/vendor/waves/waves.js"></script>
    
    <!-- Plugins -->
    <script src="<?php echo base_url();?>global/vendor/switchery/switchery.js"></script>
    <script src="<?php echo base_url();?>global/vendor/intro-js/intro.js"></script>
    <script src="<?php echo base_url();?>global/vendor/screenfull/screenfull.js"></script>
    <script src="<?php echo base_url();?>global/vendor/slidepanel/jquery-slidePanel.js"></script>
    <script src="<?php echo base_url();?>global/vendor/jquery-selective/jquery-selective.min.js"></script>
    <script src="<?php echo base_url();?>global/vendor/bootbox/bootbox.js"></script>
    
    <!-- Scripts -->
    <script src="<?php echo base_url();?>global/js/Component.js"></script>
    <script src="<?php echo base_url();?>global/js/Plugin.js"></script>
    <script src="<?php echo base_url();?>global/js/Base.js"></script>
    <script src="<?php echo base_url();?>global/js/Config.js"></script>
    
    <script src="<?php echo base_url();?>assets/js/Section/Menubar.js"></script>
    <script src="<?php echo base_url();?>assets/js/Section/Sidebar.js"></script>
    <script src="<?php echo base_url();?>assets/js/Section/PageAside.js"></script>
    <script src="<?php echo base_url();?>assets/js/Plugin/menu.js"></script>
    
    <!-- Config -->
    <script src="<?php echo base_url();?>global/js/config/colors.js"></script>
    <script src="<?php echo base_url();?>assets/js/config/tour.js"></script>
    <script>Config.set('assets', 'assets');</script>
    
    <!-- Page -->
    <script src="<?php echo base_url();?>assets/js/Site.js"></script>
    <script src="<?php echo base_url();?>global/js/Plugin/asscrollable.js"></script>
    <script src="<?php echo base_url();?>global/js/Plugin/slidepanel.js"></script>
    <script src="<?php echo base_url();?>global/js/Plugin/switchery.js"></script>
    <script src="<?php echo base_url();?>global/js/Plugin/animate-list.js"></script>
    <script src="<?php echo base_url();?>global/js/Plugin/bootbox.js"></script>
    <script src="<?php echo base_url();?>assets/js/Site.js"></script>
    <script src="<?php echo base_url();?>assets/js/App/Projects.js"></script>
    <script src="<?php echo base_url();?>assets/examples/js/apps/projects.js"></script>

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Zebra_datepicker/1.9.12/zebra_datepicker.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.blockUI/2.70/jquery.blockUI.min.js"></script>


    <script src="<?php echo base_url();?>global/vendor/datatables.net/jquery.dataTables.js"></script>
    <script src="<?php echo base_url();?>global/vendor/datatables.net-bs4/dataTables.bootstrap4.js"></script>
    <script src="<?php echo base_url();?>global/vendor/datatables.net-fixedheader/dataTables.fixedHeader.js"></script>
    <script src="<?php echo base_url();?>global/vendor/datatables.net-fixedcolumns/dataTables.fixedColumns.js"></script>
    <script src="<?php echo base_url();?>global/vendor/datatables.net-rowgroup/dataTables.rowGroup.js"></script>
    <script src="<?php echo base_url();?>global/vendor/datatables.net-scroller/dataTables.scroller.js"></script>
    <script src="<?php echo base_url();?>global/vendor/datatables.net-responsive/dataTables.responsive.js"></script>
    <script src="<?php echo base_url();?>global/vendor/datatables.net-responsive-bs4/responsive.bootstrap4.js"></script>
    <script src="<?php echo base_url();?>global/vendor/datatables.net-buttons/dataTables.buttons.js"></script>
    <script src="<?php echo base_url();?>global/vendor/datatables.net-buttons/buttons.html5.js"></script>
    <script src="<?php echo base_url();?>global/vendor/datatables.net-buttons/buttons.flash.js"></script>
    <script src="<?php echo base_url();?>global/vendor/datatables.net-buttons/buttons.print.js"></script>
    <script src="<?php echo base_url();?>global/vendor/datatables.net-buttons/buttons.colVis.js"></script>
    <script src="<?php echo base_url();?>global/vendor/datatables.net-buttons-bs4/buttons.bootstrap4.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>

    <script>
        $('.zdatepicker').Zebra_DatePicker({
            format: 'd-m-Y'
        });

        $('.data-table').DataTable( {
            "paging":   false,
            //"ordering": false,
            //"info":     false
        } );
    </script>
  </body>
</html>
